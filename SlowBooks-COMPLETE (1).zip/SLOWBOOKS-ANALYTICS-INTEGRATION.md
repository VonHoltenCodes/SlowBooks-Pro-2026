# SlowBooks + FlowFinance Analytics Integration

**Status:** Ready to implement  
**Date:** April 14, 2026  
**Scope:** Merge FlowFinance analytics into SlowBooks for comprehensive business intelligence

---

## 📊 What You're Right About

SlowBooks has the **core accounting engine** (journal posting, invoices, P&L), but it's missing the **business intelligence layer** that makes financial data *actionable*.

FlowFinance already has:
- ✅ Category-based expense analysis
- ✅ Monthly/quarterly/yearly trending
- ✅ AI insights integration (custom endpoints)
- ✅ Budget tracking & alerts
- ✅ Subscription/recurring pattern detection
- ✅ Data visualization (charts, breakdowns)

**This is exactly what an internal financial system needs.**

---

## 🎯 Integration Architecture

### Phase 1: Analytics Backend (3-4 weeks)

Add to SlowBooks `app/services/analytics.py`:

```python
# app/services/analytics.py
from decimal import Decimal
from datetime import date, timedelta
from collections import defaultdict
from sqlalchemy import func

class AnalyticsEngine:
    """Business intelligence layer for SlowBooks."""
    
    def __init__(self, db: Session):
        self.db = db
    
    # ===== Revenue Analytics =====
    
    def revenue_by_customer(self, start: date, end: date):
        """Total revenue per customer (YTD, quarterly, etc.)"""
        invoices = self.db.query(Invoice).filter(
            Invoice.date.between(start, end),
            Invoice.status == "paid"
        ).all()
        
        result = defaultdict(Decimal)
        for inv in invoices:
            result[inv.customer.name] += inv.total
        
        return dict(sorted(result.items(), key=lambda x: x[1], reverse=True))
    
    def revenue_trend(self, months: int = 12):
        """Monthly revenue trend (last N months)"""
        result = {}
        for i in range(months):
            month_start = date.today().replace(day=1) - timedelta(days=30*i)
            month_start = month_start.replace(day=1)
            month_end = (month_start + timedelta(days=32)).replace(day=1) - timedelta(days=1)
            
            total = self.db.query(func.sum(Invoice.total)).filter(
                Invoice.date.between(month_start, month_end),
                Invoice.status == "paid"
            ).scalar() or Decimal(0)
            
            result[month_start.strftime("%Y-%m")] = float(total)
        
        return result
    
    def customer_lifetime_value(self):
        """Total revenue per customer (all time)."""
        return self.revenue_by_customer(
            date(2000, 1, 1),
            date.today()
        )
    
    # ===== Expense Analytics =====
    
    def expenses_by_category(self, start: date, end: date):
        """Total expenses grouped by account type."""
        bills = self.db.query(Bill, BillLine).join(BillLine).filter(
            Bill.date.between(start, end),
            Bill.status == "paid"
        ).all()
        
        result = defaultdict(Decimal)
        for bill, line in bills:
            account = self.db.query(Account).get(line.account_id)
            category = account.account_number.split()[0]  # "5100 Labor" → "5100"
            result[category] += line.amount
        
        return dict(result)
    
    def expense_trend(self, months: int = 12):
        """Monthly expense trend (labor, materials, overhead, etc.)"""
        result = defaultdict(dict)
        
        for i in range(months):
            month_start = date.today().replace(day=1) - timedelta(days=30*i)
            month_start = month_start.replace(day=1)
            month_end = (month_start + timedelta(days=32)).replace(day=1) - timedelta(days=1)
            month_label = month_start.strftime("%Y-%m")
            
            bills = self.db.query(BillLine).join(Bill).filter(
                Bill.date.between(month_start, month_end)
            ).all()
            
            for line in bills:
                account = self.db.query(Account).get(line.account_id)
                category = account.account_number
                
                if category not in result:
                    result[category] = {}
                result[category][month_label] = float(line.amount)
        
        return dict(result)
    
    # ===== Cash Flow Analytics =====
    
    def accounts_receivable_aging(self):
        """A/R aging by customer (current, 30, 60, 90+ days)."""
        today = date.today()
        invoices = self.db.query(Invoice).filter(
            Invoice.status.in_(["sent", "partial", "overdue"])
        ).all()
        
        aging = {
            "current": defaultdict(Decimal),
            "30_days": defaultdict(Decimal),
            "60_days": defaultdict(Decimal),
            "90_plus": defaultdict(Decimal),
        }
        
        for inv in invoices:
            days_old = (today - inv.date).days
            customer = inv.customer.name
            balance = inv.total - inv.amount_paid
            
            if days_old <= 30:
                aging["current"][customer] += balance
            elif days_old <= 60:
                aging["30_days"][customer] += balance
            elif days_old <= 90:
                aging["60_days"][customer] += balance
            else:
                aging["90_plus"][customer] += balance
        
        return {k: dict(v) for k, v in aging.items()}
    
    def accounts_payable_aging(self):
        """A/P aging by vendor (same as A/R)."""
        today = date.today()
        bills = self.db.query(Bill).filter(
            Bill.status.in_(["draft", "unpaid", "partial"])
        ).all()
        
        aging = {
            "current": defaultdict(Decimal),
            "30_days": defaultdict(Decimal),
            "60_days": defaultdict(Decimal),
            "90_plus": defaultdict(Decimal),
        }
        
        for bill in bills:
            days_old = (today - bill.date).days
            vendor = bill.vendor.name
            balance = bill.amount - bill.amount_paid
            
            if days_old <= 30:
                aging["current"][vendor] += balance
            elif days_old <= 60:
                aging["30_days"][vendor] += balance
            elif days_old <= 90:
                aging["60_days"][vendor] += balance
            else:
                aging["90_plus"][vendor] += balance
        
        return {k: dict(v) for k, v in aging.items()}
    
    def days_sales_outstanding(self):
        """DSO = (A/R / Revenue) * Days"""
        thirty_days_ago = date.today() - timedelta(days=30)
        
        ar_balance = self.db.query(func.sum(Invoice.total)).filter(
            Invoice.status.in_(["sent", "partial"])
        ).scalar() or Decimal(0)
        
        revenue = self.db.query(func.sum(Invoice.total)).filter(
            Invoice.date >= thirty_days_ago,
            Invoice.status == "paid"
        ).scalar() or Decimal(0)
        
        if revenue == 0:
            return 0
        
        dso = (ar_balance / revenue) * 30
        return float(dso)
    
    def cash_flow_forecast(self, days: int = 90):
        """Forecast cash balance for next N days based on AR aging."""
        today = date.today()
        forecast = []
        
        for i in range(0, days, 7):
            forecast_date = today + timedelta(days=i)
            
            # Expected cash from AR collections
            invoices = self.db.query(Invoice).filter(
                Invoice.status == "partial",
                Invoice.due_date <= forecast_date
            ).all()
            
            expected_ar = sum(
                inv.total - inv.amount_paid for inv in invoices
            )
            
            # Expected outflows (bills due)
            bills = self.db.query(Bill).filter(
                Bill.status == "unpaid",
                Bill.due_date <= forecast_date
            ).all()
            
            expected_ap = sum(
                bill.amount - bill.amount_paid for bill in bills
            )
            
            forecast.append({
                "date": forecast_date.isoformat(),
                "expected_ar_collection": float(expected_ar),
                "expected_ap_payment": float(expected_ap),
                "net_cash_flow": float(expected_ar - expected_ap)
            })
        
        return forecast
    
    # ===== Profitability Analytics =====
    
    def margin_by_customer(self, start: date, end: date):
        """Revenue - COGS = Margin per customer."""
        customers = self.db.query(Customer).all()
        result = {}
        
        for customer in customers:
            revenue = self.db.query(func.sum(Invoice.total)).filter(
                Invoice.customer_id == customer.id,
                Invoice.date.between(start, end),
                Invoice.status == "paid"
            ).scalar() or Decimal(0)
            
            # COGS = bills linked to this customer
            cogs = self.db.query(func.sum(BillLine.amount)).join(Bill).filter(
                BillLine.memo.contains(customer.name) if BillLine.memo else False,
                Bill.date.between(start, end)
            ).scalar() or Decimal(0)
            
            margin = revenue - cogs
            margin_pct = (margin / revenue * 100) if revenue > 0 else 0
            
            result[customer.name] = {
                "revenue": float(revenue),
                "cogs": float(cogs),
                "margin": float(margin),
                "margin_pct": float(margin_pct)
            }
        
        return result
    
    def get_all_metrics(self, period: str = "month"):
        """Return comprehensive analytics snapshot."""
        if period == "month":
            start = date.today().replace(day=1)
        elif period == "quarter":
            quarter = (date.today().month - 1) // 3
            start = date.today().replace(month=quarter*3+1, day=1)
        else:  # year
            start = date.today().replace(month=1, day=1)
        
        end = date.today()
        
        return {
            "period": period,
            "start_date": start.isoformat(),
            "end_date": end.isoformat(),
            "revenue_by_customer": self.revenue_by_customer(start, end),
            "revenue_trend": self.revenue_trend(12),
            "expenses_by_category": self.expenses_by_category(start, end),
            "expense_trend": self.expense_trend(12),
            "ar_aging": self.accounts_receivable_aging(),
            "ap_aging": self.accounts_payable_aging(),
            "dso": self.days_sales_outstanding(),
            "cash_forecast": self.cash_flow_forecast(90),
            "profitability": self.margin_by_customer(start, end),
        }
```

### Phase 1.5: API Routes (1 week)

Add analytics endpoints:

```python
# app/routes/analytics.py
from fastapi import APIRouter, Depends, Query
from app.services.analytics import AnalyticsEngine
from app.database import get_db

router = APIRouter(prefix="/api/analytics", tags=["analytics"])

@router.get("/metrics")
def get_metrics(period: str = Query("month"), db: Session = Depends(get_db)):
    """Get comprehensive metrics snapshot."""
    engine = AnalyticsEngine(db)
    return engine.get_all_metrics(period)

@router.get("/revenue")
def get_revenue_metrics(db: Session = Depends(get_db)):
    """Revenue by customer, trends, LTV."""
    engine = AnalyticsEngine(db)
    return {
        "by_customer": engine.revenue_by_customer(...),
        "trend": engine.revenue_trend(),
        "ltv": engine.customer_lifetime_value()
    }

@router.get("/expenses")
def get_expense_metrics(db: Session = Depends(get_db)):
    """Expense breakdown and trends."""
    engine = AnalyticsEngine(db)
    return {
        "by_category": engine.expenses_by_category(...),
        "trend": engine.expense_trend()
    }

@router.get("/cash-flow")
def get_cash_flow(days: int = Query(90), db: Session = Depends(get_db)):
    """Cash flow forecast and DSO/DPO metrics."""
    engine = AnalyticsEngine(db)
    return {
        "forecast": engine.cash_flow_forecast(days),
        "dso": engine.days_sales_outstanding(),
        "ar_aging": engine.accounts_receivable_aging(),
        "ap_aging": engine.accounts_payable_aging()
    }

@router.get("/profitability")
def get_profitability(db: Session = Depends(get_db)):
    """Margin analysis by customer."""
    engine = AnalyticsEngine(db)
    return engine.margin_by_customer(...)
```

---

### Phase 2: Frontend Dashboard (2-3 weeks)

Add to `app/static/js/AnalyticsDashboard.js`:

```javascript
class AnalyticsDashboard {
    constructor() {
        this.charts = {};
    }
    
    async loadMetrics() {
        const response = await fetch('/api/analytics/metrics?period=month');
        const data = await response.json();
        
        this.renderKPIs(data);
        this.renderCharts(data);
        this.renderAging(data);
        this.renderForecast(data);
    }
    
    renderKPIs(data) {
        // Revenue, Expenses, Margin, DSO cards
        const html = `
            <div class="kpi-grid">
                <div class="kpi-card">
                    <div class="label">Monthly Revenue</div>
                    <div class="value">${this.fmt(this.sum(Object.values(data.revenue_by_customer)))}</div>
                </div>
                <div class="kpi-card">
                    <div class="label">Total Expenses</div>
                    <div class="value">${this.fmt(this.sum(Object.values(data.expenses_by_category)))}</div>
                </div>
                <div class="kpi-card">
                    <div class="label">DSO (Days)</div>
                    <div class="value">${data.dso.toFixed(1)}</div>
                </div>
                <div class="kpi-card">
                    <div class="label">A/R Outstanding</div>
                    <div class="value">${this.fmt(this.sum(Object.values(data.ar_aging.current)))}</div>
                </div>
            </div>
        `;
        document.getElementById('kpi-container').innerHTML = html;
    }
    
    renderCharts(data) {
        // Revenue trend (line chart)
        this.charts.revenueTrend = new Chart(
            document.getElementById('revenue-chart'),
            {
                type: 'line',
                data: {
                    labels: Object.keys(data.revenue_trend),
                    datasets: [{
                        label: 'Monthly Revenue',
                        data: Object.values(data.revenue_trend),
                        borderColor: '#00d4aa',
                        backgroundColor: 'rgba(0, 212, 170, 0.1)',
                        tension: 0.4
                    }]
                },
                options: { responsive: true, plugins: { legend: { display: true } } }
            }
        );
        
        // Expense breakdown (pie chart)
        this.charts.expenseBreakdown = new Chart(
            document.getElementById('expense-chart'),
            {
                type: 'doughnut',
                data: {
                    labels: Object.keys(data.expenses_by_category),
                    datasets: [{
                        data: Object.values(data.expenses_by_category),
                        backgroundColor: ['#ff4757', '#5b7fff', '#ffd43b', '#ff9f43']
                    }]
                }
            }
        );
    }
    
    renderAging(data) {
        // A/R aging table
        const html = `
            <table class="aging-table">
                <tr>
                    <th>Customer</th>
                    <th>Current</th>
                    <th>30+ Days</th>
                    <th>60+ Days</th>
                    <th>90+ Days</th>
                </tr>
                ${Object.entries(data.ar_aging).map(([bucket, items]) => 
                    Object.entries(items).map(([customer, amount]) => `
                        <tr>
                            <td>${customer}</td>
                            <td class="${bucket === 'current' ? 'green' : 'red'}">${this.fmt(amount)}</td>
                        </tr>
                    `).join('')
                ).join('')}
            </table>
        `;
        document.getElementById('aging-container').innerHTML = html;
    }
    
    renderForecast(data) {
        // Cash flow forecast chart
        this.charts.forecast = new Chart(
            document.getElementById('forecast-chart'),
            {
                type: 'bar',
                data: {
                    labels: data.cash_forecast.map(d => d.date),
                    datasets: [
                        {
                            label: 'Expected AR Collection',
                            data: data.cash_forecast.map(d => d.expected_ar_collection),
                            backgroundColor: '#00d4aa'
                        },
                        {
                            label: 'Expected AP Payment',
                            data: data.cash_forecast.map(d => d.expected_ap_payment),
                            backgroundColor: '#ff4757'
                        }
                    ]
                }
            }
        );
    }
    
    fmt(n) {
        return new Intl.NumberFormat('en-US', { 
            style: 'currency', 
            currency: 'USD' 
        }).format(n);
    }
    
    sum(arr) {
        return arr.reduce((a, b) => a + b, 0);
    }
}

// Init
const dashboard = new AnalyticsDashboard();
dashboard.loadMetrics();
```

---

### Phase 3: AI Insights Integration (1-2 weeks)

Plug FlowFinance's AI layer into SlowBooks:

```python
# app/services/ai_insights.py
import httpx
import json
from app.services.analytics import AnalyticsEngine

class AIInsightsEngine:
    def __init__(self, ai_endpoint: str):
        self.endpoint = ai_endpoint
    
    async def get_insights(self, db: Session):
        """Fetch AI insights from external endpoint."""
        analytics = AnalyticsEngine(db)
        metrics = analytics.get_all_metrics("month")
        
        payload = {
            "revenue": metrics["revenue_by_customer"],
            "expenses": metrics["expenses_by_category"],
            "dso": metrics["dso"],
            "ar_aging": metrics["ar_aging"],
            "cash_forecast": metrics["cash_forecast"],
            "period": "monthly"
        }
        
        async with httpx.AsyncClient() as client:
            response = await client.post(self.endpoint, json=payload)
            return response.json()
```

Then add endpoint:

```python
@router.post("/api/analytics/ai-insights")
async def get_ai_insights(db: Session = Depends(get_db)):
    """Get AI-powered insights."""
    ai_endpoint = (await get_setting(db, "ai_endpoint")).value
    
    engine = AIInsightsEngine(ai_endpoint)
    insights = await engine.get_insights(db)
    
    return {
        "insights": insights,
        "generated_at": datetime.utcnow().isoformat()
    }
```

---

## 📈 What You'll Have (After 7-8 Weeks)

### Dashboard KPIs
- Monthly/quarterly/yearly revenue
- Expense breakdown by category
- Gross/net margin trends
- Days Sales Outstanding (DSO)
- Accounts Receivable aging
- Cash position forecast

### Charts & Visualizations
- Revenue trend (12-month line chart)
- Expense breakdown (pie/doughnut)
- Customer profitability (bar chart)
- Cash flow forecast (stacked bar)
- A/R aging (table + visual)

### Business Intelligence
- Top customers by revenue
- Expense trends (identify cost savings)
- Seasonal patterns
- Customer lifetime value
- Profitability per customer
- Aging analysis (who owes you, who you owe)

### AI-Powered Insights
- Anomaly detection ("unusual expense spike")
- Forecasting ("projected revenue next quarter")
- Recommendations ("DSO is 45 days; industry is 30")
- Alerts ("3 invoices overdue >90 days")

### Automated Reports
- Weekly cash flow email
- Monthly P&L with YoY comparison
- Quarterly business review PDF

---

## 🚀 Implementation Priority

**Week 1-2:** Analytics backend (`AnalyticsEngine` class)  
**Week 3-4:** API routes + database queries  
**Week 5-6:** Frontend dashboard (KPIs, charts, aging tables)  
**Week 7:** AI insights integration  
**Week 8:** Automated reports & email delivery

---

## 💡 Why This Matters (For Aero Obsidian / Aero Controls)

Right now SlowBooks gives you:
- ✅ Recording transactions (invoices, bills, payments)
- ✅ P&L statement (historical view)

**With analytics, you get:**
- 🎯 Cash position (90-day forecast)
- 🎯 Customer profitability (which customers cost you money?)
- 🎯 Cash flow timing (when will AR be collected?)
- 🎯 Expense control (where are you overspending?)
- 🎯 Collection metrics (DSO, aging analysis)

**For Aero Controls specifically:**
- Which aircraft maintenance contracts are profitable?
- Which vendors are costing too much?
- Cash flow impact of seasonal work patterns?
- Customer payment reliability (who pays late?)

---

## ✅ Integration Checklist

- [ ] Build `AnalyticsEngine` service (12 endpoints)
- [ ] Add `/api/analytics/*` routes (5-6 endpoints)
- [ ] Create dashboard HTML template
- [ ] Integrate Chart.js for visualizations
- [ ] Add AI insights endpoint (call external LLM)
- [ ] Build automated report generator
- [ ] Test with real SlowBooks data
- [ ] Document analytics API

---

**Total Effort:** 7-8 weeks  
**Complexity:** Medium (complex queries, but standard patterns)  
**ROI:** High (transforms SlowBooks from ledger → business intelligence system)

This is what turns SlowBooks from a replacement for QB2003 into a **modern financial management platform**.

